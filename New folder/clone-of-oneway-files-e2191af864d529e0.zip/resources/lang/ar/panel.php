<?php

return [
    'site_title' => 'clone of oneway',
];
